// Model class for the Student table

package com.university.model;

public class Student {

    private int studentId;
    private String name;
    private String email;
    private String password;

    // needed for Spring to create objects automatically
    public Student() {}

    // getters and setters
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}